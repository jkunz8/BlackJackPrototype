﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace BlackJackPrototype.Model
{
    class Slots
    {

        private void Strt_Click(object sender, RoutedEventArgs e)
        {
            int slot1, slot2, slot3, bet;
            int credit = 100000;
            Random rnd = new Random();

            bet = credit - 50;

            crdt.Text = credit;

            slot1 = rnd.Next(0, 3);
            slot2 = rnd.Next(0, 3);
            slot3 = rnd.Next(0, 3);

            slt1.Text = string.Join("", slot1);
            slt2.Text = string.Join("", slot2);
            slt3.Text = string.Join("", slot3);


            if (slot1 == slot2 && slot2 == slot3)
            {
                rslt.Text = "You Win";
            }
            else
            {
                rslt.Text = "You Lose";
            }

            if(slot1 == 0 && slot2 == 0 && slot3 == 0)
            {
               credit = credit + 100;
            }
            else if (slot1 == 1 && slot2 == 1 && slot3 == 1)
            {
                credit = credit + 1000;
            }
            else if (slot1 == 2 && slot2 == 2 && slot3 == 2)
            {
                credit = credit + 10000;
            }
            else if (slot1 == 3 && slot2 == 3 && slot3 == 3)
            {
                bet = credit + 100000;
            }
        }
    }
}
